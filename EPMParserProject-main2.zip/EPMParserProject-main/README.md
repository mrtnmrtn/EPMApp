The below is a disclaimer that has not been written by a lawyer. 
As such it has very much been written to be taken in good faith.

### LIMITATION OF LIABILITY ###

    This script is provided as is. CyberArk and the author do not accept any liability for damages, time lost, etc caused by incorrect definitions or policy built off of the outputs provided (or any other products or derivatives of this utility). By using this script you accept that any result or incident that arises is your sole responsibility.

    That being said, please reach out if you have any difficulties, happy to assist.

### DEPLOYMENT RECOMMENDATION ###

    For the above reason, it is STRONGLY recommended that any implementation derived from migration or upload output is first deployed in a sandboxed testing environment, following development best practice, and then rigorously verified to ensure correctness. Care has been taken to eliminate or provide meaningful error messages for any erroneous input, however no guarantees can be made and again it is ultimately the user's responsibility to validate the outputs of this script and any future derivatives to ensure correctness of definition within EPM. 


# HOW TO USE THIS UTILITY #

## CAVEATS AND GOTCHAS ##

Due to a default call limit imposed by the tenant of 5 API calls per minute, there will be a busy-wait of 1 min after every 5 Application Groups uploaded in a single run of the program. To extend this limit please contact a CyberArk representative and then make the relevant adjustment to the following:

``constants.py``
```
  MaxApiCallsPerPeriod
  ApiCallsPeriodSec
```

## GENERAL PURPOSE ##

To split larger application groups attached to policies into more manageable sizes.

## PREREQUISITES ##

To begin, you will need to manually create a file called constants.py.

It should have the following defined:

- USERNAME = {Your EPM login name for the tenant}
- PASSWORD = {The password corresponding to your login}
- EPMServerName = {The server name of your EPM instance - as an example, "au.epm.cyberark.com" corresponds to the AU datacentre}
- ApplicationID = {The name by which you want the EPM service to recognise this application's requests - e.g. "NicholaiAPITest"}

You will also need the packages defined in requirements.txt

This was compiled on Python 3.11

### VIRTUAL ENVIRONMENT ###

To run the application in a virtual python environment to minimise potential package conflicts, run the following in the root folder: 

    Powershell (Windows)
``python -m venv .``

``.\Scripts\activate`` 

``python -m pip install -r .\requirements.txt`` 

    Bash
``python -m venv .``

``source bin/activate`` 

``pip install -r ./requirements.txt`` 

## MODELS ##

This is the expected payload for an application group chunked down into patterns for ease of extensibility and edit.

## EPM AUTHENTICATION SERVICE ##

Token management and authentication handling via class abstraction. All handled in EPM-Main

## EPM Api Service ##

Generic API call handling.

## EPM Data Service ##

API to business document translation layer

## Get Sets and Policies ##

Handy utility for retrieving sets, their policies, and application group details.



