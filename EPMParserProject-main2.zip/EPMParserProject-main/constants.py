USERNAME=""
PASSWORD=""

EPMServerName="au.epm.cyberark.com"
ApplicationID="App Group Processor"

# If set to False, application groups over the AppGroupMaxSize threshold will be created and 
# added to the relevant policy/policies.
# If set to True, the application operates as per False but the replaced policies are also deleted
DeleteReplacedPolicies=False

# Application groups over this threshold are processed
AppGroupMaxSize=700

# Matching application groups are processed into new applications groups of this maximum size
AppGroupChunkSize=600

# API call thresholding
MaxApiCallsPerPeriod=4
ApiCallsPeriodSec=60

#proxy - if UseProxy is true, you must add httpProxy and httpsProxy details
UseProxy=False
httpProxy=""
httpsProxy=""

# logging
logFile="log.txt"
logLevel="DEBUG" # CRITICAL, FATAL, ERROR, WARN, INFO, DEBUG, NOTSET
logEncoding="utf-8"
