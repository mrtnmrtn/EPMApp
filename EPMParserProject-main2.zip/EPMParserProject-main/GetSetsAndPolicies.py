import logging, constants 
from datetime import datetime

from EpmDataService import EpmDataService
from Models.SetModel import SetModel
from Documents.PoliciesResponse import PoliciesResponse
from Documents.SetsResponse import SetsResponse



def main():
    _policiesByAppGroup = {}
    _appGroupsByPolicy = {}

    setPolicies : PoliciesResponse
    sets : SetsResponse

    _epmDataService = EpmDataService()
    # sets = _epmDataService.getSets()

    sets = SetsResponse()    
    setModel = SetModel()
    setModel.Id = "<add set id here>" 
    setModel.Name = "__Manually set__"
    sets.addSet(setModel)

    for set in sets.Sets:
        print("Found SET: [{}] [{}]".format(set.Name, set.Id))

        # get all policies in the set
        # logging.info("getting set policies")
        setPolicies = _epmDataService.getPolicies(set.Id)

        # for policyWrapper in setPolicies:
        print("  Set has the following policy count: total=[{}] active=[{}] filtered=[{}]".format(setPolicies.totalCount, setPolicies.activeCount, setPolicies.filteredCount))
        for policy in setPolicies.Policies:
            if policy.IsActive:
                print("    Set has active policy name=[{}] ID=[{}] order=[{}]".format(policy.PolicyName, policy.PolicyId, policy.Order))
                for rag in policy.ReferencedApplicationGroups:
                    print("      Policy references app group=[{}]".format(rag.Id))

        # get a list of policies for each unique application group 
        processAppGroupPolicies(setPolicies, _policiesByAppGroup, _appGroupsByPolicy)

    print("============App group to policy mapping===========")
    for d in _policiesByAppGroup:
        print("App group: {}, Policies: {}".format(d, _policiesByAppGroup[d]))

    print("============Policy to app group mapping===========")
    for d in _appGroupsByPolicy:
        print("Policy: {}, App groups: {}".format(d, _appGroupsByPolicy[d]))



def processAppGroupPolicies(policies, policiesByAppGroup, appGroupsByPolicy):
    for p in policies.Policies:
        if p.IsActive:
            for rag in p.ReferencedApplicationGroups:
                addItemToDictKey(policiesByAppGroup, rag.Id, p.PolicyId)
                addItemToDictKey(appGroupsByPolicy, p.PolicyId, rag.Id)

def addItemToDictKey(dict, key, item):
    if key in dict:
        if  item not in dict[key]:
            tempItems=[]
            for i in dict[key]:
                tempItems.append(i)
            tempItems.append(item)
            dict[key] = tempItems
            logging.debug("added item [{}] to existing key [{}]".format(item, key))
    else:
        dict[key] = [item]
        logging.debug("added item [{}] to new key [{}]".format(item, key))

main()