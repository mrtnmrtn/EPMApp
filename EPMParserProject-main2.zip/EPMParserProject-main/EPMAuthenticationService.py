# import pip_system_certs.wrapt_requests
import requests
import os
from Models.authResultModel import AuthResultModel
import constants


class EPMAuthenticationService : 

    authenticationResult : AuthResultModel
    version : str 

    if (constants.UseProxy):
        proxies = {
            'http':constants.httpProxy,
            'https':constants.httpsProxy
        }
    # os.environ['HTTPS_PROXY']='https://localhost:8888'
    # # os.environ['HTTP_PROXY']='http://localhost:8888'
    # os.environ['https_proxy']='https://localhost:8888'
    # # os.environ['http_proxy']='http://localhost:8888'

    def __init__(self):
        self.authenticationResult = None
        self.version = ""

    # Function to get the most latest version of EPM Server
    def getLatestVersion(self):        
        if(self.version != None or self.version != ""):
            return self.version
        url = "https://{}/EPM/API/Server/Version".format(constants.EPMServerName)
        print("getLatestVersion - calling url [{}]".format(url))
        response = requests.get(url).json()
        if (constants.UseProxy):
            response = requests.get(url, proxies=self.proxies, verify=False).json()
        else:
            response = requests.get(url).json()

        self.version = response['Version']
        return response['Version']

    # Get Token
    def getToken(self):
        if(self.authenticationResult != None): 
            return self.authenticationResult
        # if(self.version == None or self.version == ""):
        #    version = self.getLatestVersion()
        # url = "https://{}/EPM/API/{}/Auth/EPM/Logon".format(constants.EPMServerName,version)
        url = "https://{}/EPM/API/Auth/EPM/Logon".format(constants.EPMServerName)
        # print("getToken - calling url [{}]".format(url))
        body = {
            "Username": constants.USERNAME,
            "Password": constants.PASSWORD,
            "ApplicationID": constants.ApplicationID
        }          
        if (constants.UseProxy):
            response = requests.post(url,json = body, proxies=self.proxies, verify=False).json()
        else:
            response = requests.post(url,json = body).json()
        
        token = 'basic '+ str(response['EPMAuthenticationResult'])
        managerUrl = str(response['ManagerURL'])
        self.authenticationResult = AuthResultModel(token, managerUrl)
        return self.authenticationResult