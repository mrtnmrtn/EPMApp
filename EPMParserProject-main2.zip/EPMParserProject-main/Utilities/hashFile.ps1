#Loosely working hashes script

$hashList = Import-Csv .\Locations.csv

foreach ($hash in $hashList) {
    $SHA1 = Get-FileHash $hash.Location -Algorithm SHA1 | Format-List -Property Hash
    $SHA256 = Get-FileHash $hash.Location -Algorithm SHA256 | Format-List -Property Hash
    Write-Output $SHA1 $SHA256 $hash.Location | Export-CSV -Path "/Users/Nicholai.Rank/Documents/hashOutput.csv"
}