import json
from Models.PolicyModel import PolicyModel

class PoliciesResponse:
    policies : list[PolicyModel]
    activeCount : int
    totalCount : int
    filteredCount : int

    def __init__(self):
        self.Policies = []
    
    def addPolicy(self, policyId, policyName, action, isActive, policyType, order, isAppliedToAllComputers, osType, createdDate, modifiedDate, referencedApplicationGroups, userPolicyPermissions, extraInfo):        
        self.Policies.append(PolicyModel(policyId, policyName, action, isActive, policyType, order, isAppliedToAllComputers, osType, createdDate, modifiedDate, referencedApplicationGroups, userPolicyPermissions, extraInfo))
    
    def addPolicyModel(self, policyModel):        
        self.Policies.append(policyModel)
    
    