import json

class ApplicationGroupDetailsResponse:
    def __init__(self, applicationGroupDetailsPolicyModel, order, osType, createdDate, modifiedDate):
        self.policy = applicationGroupDetailsPolicyModel
        self.order = order
        self.osType = osType
        self.createdDate = createdDate 
        self.modifiedDate = modifiedDate

    def toJson(self):
        # return json.dumps(self, default=lambda o: o.__dict__,sort_keys=True, ensure_ascii=True, indent=4)
        return json.dumps(self, default=lambda o: o.__dict__,sort_keys=True, indent=4)
