import json

class ApplicationPolicyModel:
    Audit : vars # bool
    Applications : vars # []
    Activation : vars 
    Priority : vars # int
    Id : vars # guid
    Name : vars # str
    Description : vars # str
    PolicyType : vars # int
    IsActive : vars # bool
    Action : vars # int
    Executors : vars # []
    IsAppliedToAllComputers : vars # bool
    Accounts : vars # []
    IncludeADComputerGroups : vars # []
    ExcludeADComputerGroups : vars # []

    def __init__(self):
        pass

    def toJson(self):
        return json.dumps(self, default=lambda o: o.__dict__,sort_keys=True, indent=4)   
       