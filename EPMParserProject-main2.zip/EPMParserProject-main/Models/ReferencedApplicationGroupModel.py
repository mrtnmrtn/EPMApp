class ReferencedApplicationGroupModel:
    def __init__(self, id, referenceType):
        self.Id = id
        self.ReferenceType = referenceType