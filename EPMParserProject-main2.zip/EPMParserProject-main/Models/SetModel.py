class SetModel:    
    Id : vars # str
    Name : vars # str
    Description : vars # str
    IsNPVDI : vars # bool
    SetType : vars

    def __init__(self):
        pass
