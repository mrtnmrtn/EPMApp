class AuthResultModel:
    Token : str
    ManagerUrl: str

    def __init__(self, token, managerUrl):
        self.Token = token
        self.ManagerUrl = managerUrl 