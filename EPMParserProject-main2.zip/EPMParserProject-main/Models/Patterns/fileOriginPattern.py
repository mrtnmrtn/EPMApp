class FileOriginPattern:

    type : str
    def __init__(self) :
        self.type = "FileOrigin"