class PublisherPattern:

    type: str
    signatureLevel: int
    separator: str
    caseSensitive : bool
    compareAs: int
    isEmpty: bool
    content: str
    def __init__(self, content,signatureLevel=2, separator=";", caseSensitive=False,compareAs=1):
        self.type = "Publisher"
        self.signatureLevel = signatureLevel
        self.separator = separator
        self.caseSensitive = caseSensitive
        self.compareAs = compareAs
        self.content = content
        self.isEmpty = False
        if content == "" : 
            self.isEmpty = True
            self.signatureLevel = 0