class ProductVersionPattern:

    type : str

    def __init__(self) :
        self.type = "VersionRange"