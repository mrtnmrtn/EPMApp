class ServiceNamePattern:

    type : str
    content : str

    def __init__(self,content) :
        self.type = "Text"
        self.content = content