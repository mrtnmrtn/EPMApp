class FileNamePattern:

    type : str
    content: str
    isEmpty: bool
    compareAs: int
    caseSensitive : bool
    hashAlgorithm : str
    hashSHA256 : str
    hash: str

    def __init__(self, content, compareAs = 0, caseSensitive = False, hashAlgorithm="", hashSHA256="") :
        self.type = "FileName"
        self.content = content
        self.compareAs = compareAs
        self.caseSensitive = caseSensitive
        self.hashAlgorithm = hashAlgorithm
        self.hashSHA256 = hashSHA256
        if(content == ""): self.isEmpty = True
        else: self.isEmpty = False