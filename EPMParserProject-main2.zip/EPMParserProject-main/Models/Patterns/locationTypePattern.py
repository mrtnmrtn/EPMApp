class LocationTypePattern:
    type: str
    locationType: str

    def __init__(self, locationType = "FIXED"):
        self.type = "LocationType"
        self.locationType = locationType