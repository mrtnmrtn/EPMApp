class FileVersionPattern:

    type : str
    minVersion : str
    isEmpty : bool

    def __init__(self, minVersion="", isEmpty=True):
        self.type = "VersionRange"
        self.minVersion = minVersion
        self.isEmpty = isEmpty