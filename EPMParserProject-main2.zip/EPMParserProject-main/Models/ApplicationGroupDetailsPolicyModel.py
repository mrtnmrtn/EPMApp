import json

class ApplicationGroupDetailsPolicyModel:
    id : vars
    Name : vars
    PolicyType : vars
    description : vars
    Applications : vars
    linkedAgentPolicies : vars

    def __init__(self):
        pass

    def toJson(self):
         return json.dumps(self, default=lambda o: o.__dict__,sort_keys=True, indent=4)
        #  return json.dumps(self, default=lambda o: o.__dict__,sort_keys=True, indent=4, ensure_ascii=False)