class LinkedAgentPolicy:
    def __init__(self, id, policyType, defaultApplicationGroupId):
        self.Id = id
        self.PolicyType = policyType
        self.DefaultApplicationGroupId = defaultApplicationGroupId
        