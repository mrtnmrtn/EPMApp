import json
import re
import csv
import copy
from time import sleep
from typing import List
from EpmDataService import EpmDataService
from Models.Patterns.fileNamePattern import FileNamePattern
from Models.Patterns.fileOriginPattern import FileOriginPattern
from Models.Patterns.fileVersionPattern import FileVersionPattern
from Models.Patterns.locationPattern import LocationPattern
from Models.Patterns.locationTypePattern import LocationTypePattern
from Models.Patterns.parentProcessPattern import ParentProcessPattern
from Models.Patterns.productVersionPattern import ProductVersionPattern
from Models.Patterns.publisherPattern import PublisherPattern
from Models.Patterns.serviceNamePattern import ServiceNamePattern
from Models.applicationGroupModel import ApplicationGroupModel
from Models.applicationModel import ApplicationType
from Models.patternModel import PatternModel
from Models.setInformationModel import SetInformationModel

class EPMUpdate:
    _epmDataService : EpmDataService

    def main():
        def parseCSV(filename):
            applications = []
            with open(filename, newline='') as csvfile:
                reader = csv.reader(csvfile, quotechar='|')
                for row in reader:
                    temp = copy.deepcopy(row)
                    applications.append(temp)
            return applications[1:]
        res = parseCSV('EPMBatchUploadCSVTemplate.csv')
        
        appGroupSets = {}
        line = 1
        for app in res:
            line+=1
            setId = app[0]
            if(setId == "" or setId == None): raise Exception("###Set Id cannot be empty on line {}###".format(line))

            appGroupName = app[15]
            if(appGroupName == "" or appGroupName == None): raise Exception("###App Group Name cannot be empty on line {}###".format(line))
            # if setId in appGroupSets:

            applicationModel = ApplicationType()
            applicationModel.displayName = app[3]
            applicationModel.description = app[2]
            applicationChildProcesses = False
            if app[8].lower() == "true": 
                applicationChildProcesses = True
            applicationModel.childProcess = applicationChildProcesses
            
            #Default
            applicationModel.applicationType = 3
            if str(app[1]) == 'exe' or str(app[1]) == '.exe':
                applicationModel.applicationType = 3
            elif str(app[1]) == 'script':
                applicationModel.applicationType = 4
            # elif str(app[1]) == 'dll':
            #     applicationModel.applicationType = 21
            
            # HardCoded Values 
            applicationModel.applicationGroupId = "00000000-0000-0000-0000-000000000000"
            applicationModel.internalApplicationGroupId = 0
            applicationModel.accountId = "00000000-0000-0000-0000-000000000000"
            applicationModel.restrictOpenSaveFileDialog  = True
            applicationModel.securityTokenId = "00000000-0000-0000-0000-000000000000"
            applicationModel.protectInstalledFiles = False


            patternModel = PatternModel()

            # File_NAME Pattern
            #needs a check for invalid Hash - i.e. 256 with no 1
            fileNamePattern = FileNamePattern(app[4])
            if(app[4]!=""):
                # if('.exe' in str(app[4])):
                #     fileNamePattern = FileNamePattern(app[4])
                # elif(app[1]=='exe'):
                #     fileNamePattern = FileNamePattern(app[4]+'.exe')
                # else:
                #     fileNamePattern = FileNamePattern(app[4])
                
                if(not fileNamePattern.content.__contains__('.')):
                    raise Exception('###File Name neeeds an extension on line {}###'.format(line))
            if app[5] != "":
                fileNamePattern.hashAlgorithm = "SHA1"
                fileNamePattern.hashSHA256=app[5]
                
            fileNamePattern.hash = app[13]

            #If they're not both null
            if not ((fileNamePattern.hash == "" or fileNamePattern.hash == None) and (fileNamePattern.hashSHA256 == "" or fileNamePattern.hashSHA256 == None)):
                #If one of them is null but not the other
                if ((fileNamePattern.hash == "" or fileNamePattern.hash == None) or (fileNamePattern.hashSHA256 == "" or fileNamePattern.hashSHA256 == None)):
                    raise Exception("###Need to Have Both SHA1 And SHA256 defined for a correct hash on line {}###".format(line))
            
            if(app[4] == '' and app[5] == '' and app[13]== ''): fileNamePattern = None

            # Location Pattern
            if(app[6] == '' and app[7] != '') : raise Exception("###Can not have subfolders matching when location not provided on line {}###".format(line))
            locationWithSubFolders = False
            if app[7].lower() == "true": locationWithSubFolders = True
            locationPattern = LocationPattern(app[6],locationWithSubFolders)
            if(app[6] == ''):
                locationPattern = None


            # Publisher Pattern
            publisherPattern = None
            if(app[9] == '' and app[10] != '') : raise Exception("###Can not have Compare As when Publisher Name is not provided on line {}###".format(line))
            if app[9] != "" :
                publisherPattern = PublisherPattern(app[9])
                if app[10] != "" : publisherPattern.compareAs = int(app[10])
                else: publisherPattern.compareAs = 1
            # LocationType Pattern


            #Location Also Needs exe comparator.
            locationTypePattern = LocationTypePattern()
            locationType = ""
            if app[12].lower() == "true": locationType = "FIXED"
            locationTypePattern.locationType = locationType
            if(locationTypePattern.locationType == ''): locationTypePattern = None

            

            if(fileNamePattern != None): patternModel.FILE_NAME = fileNamePattern
            if(locationPattern != None):  patternModel.LOCATION = locationPattern
            if(locationTypePattern != None):  patternModel.LOCATION_TYPE = locationTypePattern
            if(publisherPattern != None): patternModel.PUBLISHER = publisherPattern

            if(fileNamePattern == None and locationPattern == None and locationTypePattern == None and publisherPattern == None):
                raise Exception("###Need to Have at least One Pattern on line {}###".format(line))
            
            
            applicationModel.patterns = patternModel
            #PostProcessing of a created application to appropriately group by AppGroup then Set.
            if setId in appGroupSets:
                flag = False
                for appGroupModel in appGroupSets[setId]:
                    if appGroupModel.Name == appGroupName:
                        applicationGroupModel.Description = applicationModel.description
                        appGroupModel.Applications.append(applicationModel)
                        flag = True
                        break
                        
                if flag == False: 
                    applicationGroupModel = ApplicationGroupModel()
                    applicationGroupModel.Name = appGroupName
                    applicationGroupModel.PolicyType = 14
                    applicationGroupModel.Applications =  [applicationModel]
                    applicationGroupModel.Description = applicationModel.description
                    appGroupSets[setId].append(applicationGroupModel)
            else: 
                #initial case - when setID doesn't exist in the dict.
                applicationGroupModel = ApplicationGroupModel()
                applicationGroupModel.Name = appGroupName
                applicationGroupModel.Description = applicationModel.description
                applicationGroupModel.PolicyType = 14
                applicationGroupModel.Applications = [applicationModel]
                appGroupSets[setId] = [applicationGroupModel]
            

        return appGroupSets

    def uploadToEPM(appSetDict, _epmDataService):
        count=0
        for key, value in appSetDict.items():
            for object in value:
                if(count==4):
                    sleep(60)
                    count=0
                finalJson = json.loads(re.sub("\"type\":", "\"@type\":", object.toJSON()))
                res = _epmDataService.createApplicationGroup(key , finalJson )
                responseJson = json.loads(res.text)
                if(res.ok == True):
                    print(key +" ---------> "+responseJson['Id'] + " --------> " + responseJson['Name'])
                else: 
                    print(responseJson)
                    print("WARNING Operation returned error status code. This entry was not added to EPM.")
                    print("SetId: " + key + " App Group Name: " + object.Name)
                count+=1


    if __name__ == "__main__":
        _epmDataService = EpmDataService()
        obj = main()
        # uploadToEPM(obj, _epmDataService)

       