import json
from Models.applicationModel import ApplicationType
from typing import List


class ApplicationGroupModel:
    Name: str
    PolicyType: str
    Description: str
    Applications: List[ApplicationType]

    def __init__(self) :
        pass

    def toJSON(self):
        return json.dumps(self, default=lambda o: o.__dict__, 
            sort_keys=True, indent=4)