import json
from EpmDataService import EpmDataService
from Models.setModel import SetModel
from Documents.SetsResponse import SetsResponse

_epmDataService = EpmDataService()
# model = SetModel("myid", "myname", "mydescription", "false", 1)

# print("id: ", model.Id)
# print("name: ", model.Name)
# print("description: ", model.Description)
# print("isNPVDI: ", model.IsNPVDI)
# print("setType: ", model.SetType)

# setresp = SetResponse()
# setresp.addSet("myid1", "myname", "mydescription", "false", 1)
# setresp.addSet("myid2", "myname", "mydescription", "false", 1)
# print(setresp.SetsCount())
# for s in setresp.Sets:
#     print(s.Id)


setresp = _epmDataService.getSets()
print(setresp.SetsCount())
for s in setresp.Sets:
    print("set.Id: ",s.Id)

policiesResp = _epmDataService.getPolicies(setresp.Sets[0].Id)
print(policiesResp.ActiveCount())
for p in policiesResp.Policies:
    print("policy.PolicyId", p.PolicyId)

# _epmDataService = EpmDataService()
# # sets = _epmDataService.getSetLists()
# # for entry in sets:
# #     print("Set: ")
# #     print("     Name: ",entry.Name)
# #     print("     ID: ",entry.Id)

# policies = _epmDataService.getPolicies("f54983ad-1111-4414-94dd-bf6b1b1cc3b5")

# # print("++++++", policies["Policies"][0]["ReferencedApplicationGroups"][0]["Id"])

# for policy in policies["Policies"]:
#     print(policy["PolicyId"])
#     print(policy["PolicyName"])
#     print(policy["ReferencedApplicationGroups"])

