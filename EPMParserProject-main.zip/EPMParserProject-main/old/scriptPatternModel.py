from Models.Patterns.fileNamePattern import FileNamePattern
from Models.Patterns.fileOriginPattern import FileOriginPattern
from Models.Patterns.fileVersionPattern import FileVersionPattern
from Models.Patterns.locationPattern import LocationPattern
from Models.Patterns.locationTypePattern import LocationTypePattern
from Models.Patterns.parentProcessPattern import ParentProcessPattern
from Models.Patterns.productVersionPattern import ProductVersionPattern
from Models.Patterns.publisherPattern import PublisherPattern
from Models.Patterns.serviceNamePattern import ServiceNamePattern


class PatternModel:
    FILE_NAME : FileNamePattern
    LOCATION : LocationPattern
    LOCATION_TYPE : LocationTypePattern
    PUBLISHER : PublisherPattern
    FILE_VERSION : FileVersionPattern
    PRODUCT_VERSION : ProductVersionPattern
    FILE_ORIGIN : FileOriginPattern
    PARENT_PROCESS : ParentProcessPattern
    SERVICE_NAME : ServiceNamePattern



    def __init__(self):
        pass