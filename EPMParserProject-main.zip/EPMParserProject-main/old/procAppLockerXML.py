import xmltodict
import json
import csv
import re
with open("AppLockerPolicy.xml") as xml_file:
    data_dict = xmltodict.parse(xml_file.read())
    json_data = json.dumps(data_dict)

#Add translations for scripts when able.

##Currently does not process scripts ##

def extractorAppLockerEXE(js): 
    js=json.loads(js)
    v = js['AppLockerPolicy']['RuleCollection'][2]
    #Note 2 is for exe


    #Case for 0 entries - the try except block.
    returnArray = [] 
    line = 1
    try:
        if(v['FilePublisherRule']!=None):
            if(type(v['FilePublisherRule'])==dict):
                v['FilePublisherRule']=[v['FilePublisherRule']]
            rules = v['FilePublisherRule']
            for entry in rules:
                line+=1
                displayName = entry['@Name']
                description = entry['@Description']
                action = entry['@Action']
                conditions = entry['Conditions']['FilePublisherCondition']
                publisher = str(conditions['@PublisherName'])
                publisher = publisher.split(',')[0]
                publisher = publisher.split('=')[1]
                fileName = ''
                if(conditions['@BinaryName']!="*"):
                    fileName = conditions['@BinaryName']
                appLockerTargetGroup = entry['@UserOrGroupSid']
                returnArray.append(['','exe',description,displayName,fileName,'','','','',publisher,'2','','','',action,'',appLockerTargetGroup])
    except:
        pass

    try: 
        if(v['FilePathRule']!=None):
            if(type(v['FilePathRule'])==dict):
                v['FilePathRule']=[v['FilePathRule']]
            rules = v['FilePathRule']
            for entry in rules:
                line+=1
                displayName = entry['@Name']
                description = entry['@Description']
                action = entry['@Action']
                conditions = entry['Conditions']['FilePathCondition']
                path = str(conditions['@Path'])
                location = str(conditions['@Path'])
                if '.exe' in path:
                    if('/' in path):
                        location = path.split('/')[:-1]
                        loc = ''
                        for i in location:
                            loc += '/'+str(i)
                        location = loc
                        fileName = path.split('/')[-1]
                    elif ('\\' in path):
                        location = path.split('\\')[:-1]
                        loc = ''
                        for i in location:
                            loc += '\\'+str(i)
                        location = loc[1:]
                        fileName = path.split('\\')[-1]
                
                if '%PROGRAMFILES%' in path:
                    location = location.replace('%PROGRAMFILES%', 'C:\Program Files (x86)')
                if '%' in path:
                    print(" ## WARNING: PATH \"{}\" MAY BE LEGACY - Manual Review Required on line {} ## ".format(path,line))
                    print(' ## Replaced path with {} on line {} ## '.format(location,line))
                appLockerTargetGroup = entry['@UserOrGroupSid']
                returnArray.append(['','exe',description,displayName,fileName,'',location,False,'','','','','','',action,'',appLockerTargetGroup])
    except:
        pass

    try:
        if(v['FileHashRule']!=None):
            if(type(v['FileHashRule'])==dict):
                v['FileHashRule']=[v['FileHashRule']]
            rules = v['FileHashRule']
            for entry in rules:
                line+=1
                displayName = entry['@Name']
                description = entry['@Description']
                action = entry['@Action']
                conditions = entry['Conditions']['FileHashCondition']['FileHash']
                #Check type and map to hash field
                #check sourcefilename and add to filename
                #check source file length and add to length
                appLockerTargetGroup = entry['@UserOrGroupSid']
                if(conditions['@Type']=="SHA256"):
                    returnArray.append(['','exe',description,displayName,'',conditions['@Data'],'',False,'','','','','','',action,'',appLockerTargetGroup])
                elif(conditions['@Type']=="SHA1"):
                    returnArray.append(['','exe',description,displayName,'','','',False,'','','','','',conditions['@Data'],action,'',appLockerTargetGroup])
                else:
                    raise Exception("###EPM cannot handle any hash beyond SHA256 or SHA1 on line{}###".format(line))
    except:
        pass

    
    finalArr=[]
    for entry in returnArray:
        newArr=[]
        for i in entry:
            if(i != ''): 
                i =  re.sub(',','',str(i))
            newArr.append(i)
        finalArr.append(newArr)
    with open("AppLockerOutput.csv", 'w') as csv_file:
        writer = csv.writer(csv_file, delimiter=',')
        writer.writerow(['SetID','ObjectType','Description','DisplayName','Filename','Hash-SHA256','Location','SubfoldersIncluded','ChildProcessesIncluded','Publisher','ComparePublisherAs','Version','LocalDiskOnly','Hash-SHA1','AppLockerAction','GroupName','AppLockerTarget'])
        writer.writerows(finalArr)

    #json_formatted_str = json.dumps(v, indent=2)
    #print(json_formatted_str)

extractorAppLockerEXE(json_data)