USERNAME=""
PASSWORD=""
EPMServerName="au.epm.cyberark.com"
ApplicationID="App Group Processor"

DeleteReplacedPolicies=False

AppGroupMaxSize=700
AppGroupChunkSize=600

# API call thresholding
MaxApiCallsPerPeriod=4
ApiCallsPeriodSec=60

#proxy
UseProxy=False
httpProxy=""
httpsProxy=""

# logging
logFile="log.txt"
logLevel="DEBUG" # CRITICAL, FATAL, ERROR, WARN, INFO, DEBUG, NOTSET
logEncoding="utf-8"
