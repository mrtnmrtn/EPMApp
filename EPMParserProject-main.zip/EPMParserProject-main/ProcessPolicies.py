from EpmDataService import EpmDataService
from Models.ApplicationGroupDetailsPolicyModel import ApplicationGroupDetailsPolicyModel
from Models.ApplicationPolicyModel import ApplicationPolicyModel
from Models.ApplicationModel import ApplicationModel
from Models.SetModel import SetModel
from Documents.PoliciesResponse import PoliciesResponse
from Documents.SetsResponse import SetsResponse
from datetime import datetime
import constants, math, logging

logging.basicConfig(filename="{}-log.txt".format((datetime.now()).strftime('%Y%m%d-%H%M%S'))
                    , encoding=constants.logEncoding
                    , level=logging.getLevelName(constants.logLevel)
                    , format='%(asctime)s %(levelname)s %(message)s'
                    , datefmt='%Y%m%d-%H:%M:%S')

_epmDataService = EpmDataService()


def main():
    _policiesByAppGroup = {}
    _newPoliciesByAppGroup = {}
    _newAppGroupsByPolicy = {}
    _originalToNewAppGroupMapping = {}
    setPolicies : PoliciesResponse
    sets : SetsResponse

    print("============START {}===========".format(datetime.now()))
    logging.info("===========Starting run============")
    ####################################################
    # get all sets
    # sets = _epmDataService.getSets()
    ###################### OR ##########################
    # just process one set
    sets = SetsResponse()    
    setModel = SetModel()
    setModel.Id = "<guid here>" 
    setModel.Name = "__Manually set__"
    sets.addSet(setModel)
    #####################################################

    # process all sets in tenant    
    for set in sets.Sets:
        logging.info("Starting processing SET: [{}] [{}]".format(set.Name, set.Id))

        # get all policies in the set
        logging.info("getting set policies")
        setPolicies = _epmDataService.getPolicies(set.Id)

        # get a list of policies for each unique application group 
        processAppGroupPolicies(setPolicies, _policiesByAppGroup)

        # process each unique application group
        for appgrp in _policiesByAppGroup:
            # get appliction group details
            appGroupDetails = _epmDataService.getAppGroupDetails(set.Id, appgrp)

            # find application groups larger than threshold
            if len(appGroupDetails.policy.Applications) > constants.AppGroupMaxSize:
                logging.info("App group Name: [{}] Id: [{}] app count: [{}] is larger than threshold: [{}]".format(appGroupDetails.policy.Name, appgrp, len(appGroupDetails.policy.Applications), constants.AppGroupMaxSize))
                # create new smaller application groups
                createNewApplicationGroups(appGroupDetails.policy, set.Id, appgrp, _policiesByAppGroup, _newAppGroupsByPolicy, _newPoliciesByAppGroup, _originalToNewAppGroupMapping, constants.AppGroupChunkSize)
            else:
                logging.info("App group Name: [{}] Id: [{}] app count: [{}] is smaller than threshold: [{}]".format(appGroupDetails.policy.Name, appgrp, len(appGroupDetails.policy.Applications), constants.AppGroupMaxSize))

        # prepare updated policies
        newPolicies = generatePolicyUpdates(_newAppGroupsByPolicy, _originalToNewAppGroupMapping, setPolicies, constants.DeleteReplacedPolicies)
        
        for newPolicy in newPolicies:
            updatePolicyResponse = _epmDataService.updatePolicy(set.Id, newPolicy.Id, newPolicy)

        for originalAppGroup in _originalToNewAppGroupMapping:
            deleteAppGroupResponse = _epmDataService.deleteApplicationGroup(set.Id, originalAppGroup)

    # print("============_policiesByAppGroup===========")
    logging.debug("============_policiesByAppGroup===========")
    for d in _policiesByAppGroup:
        logging.debug("key: {}, value: {}".format(d, _policiesByAppGroup[d]))

    print("============_newPoliciesByAppGroup===========")
    for d in _newPoliciesByAppGroup:
        logging.debug("key: {}, value: {}".format(d, _newPoliciesByAppGroup[d]))

    print("============_newAppGroupsByPolicy===========")
    for d in _newAppGroupsByPolicy:
        logging.debug("key: {}, value: {}".format(d, _newAppGroupsByPolicy[d]))

    print("============_originalToNewAppGroupMapping===========")
    for d in _originalToNewAppGroupMapping:
        logging.debug("key: {}, value: {}".format(d, _originalToNewAppGroupMapping[d]))
    

    print("============FINISHED {}===========".format(datetime.now()))

    logging.info("===========Ending run============")
# def processSingleSet(setId):

def createNewApplicationGroups(policy, setId, appGroupId, _policiesByAppGroup, newAppGroupsByPolicy, newPoliciesByAppGroup, originalToNewAppGroupMapping, chunkSize):
    numberOfChunks =  math.ceil(len(policy.Applications) / chunkSize)
    chunkIndex = 0 #0,1,2,3 

    # process large application group into smaller groups
    while chunkIndex < numberOfChunks:               
        newAppGroup = generateAppGroupChunksFromPolicy(chunkIndex, numberOfChunks, policy)
        createAppGroupResponse = _epmDataService.createApplicationGroup(setId, newAppGroup)
        
        logging.debug("about to add old-new app group mapping")
        addItemToDictKey(originalToNewAppGroupMapping, appGroupId, createAppGroupResponse.id)
        logging.debug("finished adding old-new app group mapping")

        for pol in _policiesByAppGroup[appGroupId]:    
            logging.debug("about to add old-new app group mapping")            
            addItemToDictKey(newPoliciesByAppGroup, createAppGroupResponse.id, pol)
            logging.debug("finished adding old-new app group mapping")
            logging.debug("about to add new app group by policy mapping")
            addItemToDictKey(newAppGroupsByPolicy, pol, createAppGroupResponse.id)
            logging.debug("finished adding new app group by policy mapping")

        chunkIndex+=1

def processAppGroupPolicies(policies, policiesByAppGroup):
    for p in policies.Policies:
        if p.IsActive:
            logging.debug("about to add policies by app group")
            for rag in p.ReferencedApplicationGroups:
                addItemToDictKey(policiesByAppGroup, rag.Id, p.PolicyId)
            logging.debug("finished adding policies by app group")

def generateAppGroupChunksFromPolicy(chunkIndex, numberOfChunks, policy):
    newAppGroup = ApplicationGroupDetailsPolicyModel()
    newAppGroup.Name = "[{} of {}] {}".format(chunkIndex+1, numberOfChunks, policy.Name)
    newAppGroup.PolicyType = policy.PolicyType
    logging.debug("Generating app chunk [{}/{}] Name[{}] PolicyType [{}]".format(chunkIndex+1, numberOfChunks, newAppGroup.Name, newAppGroup.PolicyType))
    tempApplications = []

    applicationIndex = chunkIndex*constants.AppGroupChunkSize #0,200,400,600
    applicationChunkIndex = 0

    while (applicationChunkIndex < constants.AppGroupChunkSize) and (applicationIndex+applicationChunkIndex < len(policy.Applications)):
        appToUpdate = policy.Applications[applicationIndex+applicationChunkIndex]
        tempApplications.append(appToUpdate)
        applicationChunkIndex+=1

    newAppGroup.linkedAgentPolicies = policy.linkedAgentPolicies
    newAppGroup.Applications = tempApplications

    return newAppGroup

def generatePolicyUpdates(newAppGroupsByPolicy, originalToNewAppGroupMapping, policies, deleteOld):
    newPolicies = []
    for pol in newAppGroupsByPolicy: 
        apps = []        
        newPolicy = ApplicationPolicyModel()
        existingAppGroupIds = []

        # add all referenced application groups in the existing policy to the new policy
        for p in policies.Policies:
            if p.PolicyId == pol:
                for rag in p.ReferencedApplicationGroups:
                    app = ApplicationModel()
                    app.id = rag.Id
                    app.applicationType = 2
                    apps.append(app)
                    existingAppGroupIds.append(app.id)
                    logging.info("adding existing application group [{}] to policy [{}]".format(rag.Id, pol))
                newPolicy.Action=p.Action
                newPolicy.Id=p.PolicyId
                newPolicy.PolicyType=p.PolicyType
                newPolicy.IsAppliedToAllComputers=p.IsAppliedToAllComputers
                newPolicy.Name=p.PolicyName
        
        # add new application groups to new policy
        for appgrp in newAppGroupsByPolicy[pol]:
            app = ApplicationModel()
            app.id = appgrp
            app.applicationType = 2
            existingAppGroupIds.append(app.id)
            apps.append(app)
            logging.info("adding new application group [{}] to policy [{}]".format(appgrp, pol))

        # remove 
        if deleteOld:
            for originalAppGroupId in originalToNewAppGroupMapping:
                newAppGroupCollection = originalToNewAppGroupMapping[originalAppGroupId]
                if set(newAppGroupCollection).issubset(set(existingAppGroupIds)):
                    logging.info("Remove old application group [{}] from policy [{}]".format(originalAppGroupId, pol))        
                    apps = [x for x in apps if x.id != originalAppGroupId]

        newPolicy.Applications=apps
        newPolicies.append(newPolicy)
    return newPolicies
    
def addItemToDictKey(dict, key, item):
    if key in dict:
        if  item not in dict[key]:
            tempItems=[]
            for i in dict[key]:
                tempItems.append(i)
            tempItems.append(item)
            dict[key] = tempItems
            logging.debug("added item [{}] to existing key [{}]".format(item, key))
    else:
        dict[key] = [item]
        logging.debug("added item [{}] to new key [{}]".format(item, key))

logging.info("entering main")
main()
logging.info("exited main")

# # Auth
# # Get sets
# # Foreach set (
# # 	Get policies
# # 	Foreach policy (
# # 		Foreach ReferencedApplicationGroup (
# # 			Get app group details
# # 			Count details
# #
# #           create new app groups (tagged)
# #           [opt] remove old app groups (must ensure all references updated)
#       update policy
#           add new app groups




