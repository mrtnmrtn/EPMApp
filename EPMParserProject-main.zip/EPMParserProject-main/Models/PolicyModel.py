import json

class PolicyModel:    
    PolicyId : vars
    PolicyName : vars
    Action : vars
    IsActive : vars
    PolicyType : vars
    Order : vars
    IsAppliedToAllComputers : vars
    OsType : vars
    CreatedDate : vars
    ModifiedDate : vars
    ReferencedApplicationGroups : vars
    UserPolicyPermissions : vars
    ExtraInfo : vars

    def __init__(self):
        pass

    def toJson(self):
         return json.dumps(self, default=lambda o: o.__dict__,sort_keys=True, indent=4)
    
