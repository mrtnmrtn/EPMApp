class ParentProcessPattern:

    type : str

    def __init__(self) :
        self.type = "ParentProcess"