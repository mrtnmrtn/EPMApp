class LocationPattern: 
    type :str
    content : str
    withSubfolders: bool
    def __init__(self, content, withSubfolders= False):
        self.type = "Location"
        self.content = content
        self.withSubfolders = withSubfolders
        