import json

class ApplicationModel:
    id : vars
    # internalId : vars
    applicationType : vars
    displayName : vars
    description : vars
    patterns : vars
    applicationGroupId : vars
    internalApplicationGroupId : vars
    includeInMatching : vars
    accountId : vars
    childProcess : vars
    restrictOpenSaveFileDialog : vars
    securityTokenId : vars
    protectInstalledFiles : vars
    Name : vars

    def __init__(self):
        pass
    
    def toJson(self):
        return json.dumps(self, default=lambda o: o.__dict__,sort_keys=True, indent=4)   