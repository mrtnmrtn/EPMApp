import json
from Models.SetModel import SetModel

class SetsResponse:
    Sets : list[SetModel]

    def __init__(self):
        self.Sets = []
        pass

    def SetsCount(self):
        return len(self.Sets)
    
    def addSet(self, set):     
        self.Sets.append(set)
    
    