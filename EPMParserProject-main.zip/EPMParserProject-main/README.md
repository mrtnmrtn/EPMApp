The below is a disclaimer that has not been written by a lawyer. 
As such it has very much been written to be taken in good faith.

### LIMITATION OF LIABILITY ###

    This script is provided as is. CyberArk and the author do not accept any liability for damages, time lost, etc caused by incorrect definitions or policy built off of the outputs provided (or any other products or derivatives of this utility). By using this script you accept that any result or incident that arises is your sole responsibility.

    That being said, please reach out if you have any difficulties, happy to assist.

### DEPLOYMENT RECOMMENDATION ###

    For the above reason, it is STRONGLY recommended that any implementation derived from migration or upload output is first deployed in a sandboxed testing environment, following development best practice, and then rigorously verified to ensure correctness. Care has been taken to eliminate or provide meaningful error messages for any erroneous input, however no guarantees can be made and again it is ultimately the user's responsibility to validate the outputs of this script and any future derivatives to ensure correctness of definition within EPM. 

    This is why no functionality exists at present within the utility to push definitions to an active policy, requiring manual review before enforcement as a buffer.


# HOW TO USE THIS UTILITY #

## CAVEATS AND GOTCHAS ##

Due to a default call limit imposed by the tenant of 5 API calls per minute, there will be a busy-wait of 1 min after every 5 Application Groups uploaded in a single run of the program. To extend this limit please contact a CyberArk representative and then make the relevant adjustment to the following:

``constants.py``
```
  MaxApiCallsPerPeriod
  ApiCallsPeriodSec
```

## GENERAL PURPOSE ##

The first functionality that has been created is batch upload of application definitions via CSV. Currently this is limited to the associated csv template - like VPAM csv onboarding, however it can be readily extended. It radically simplifies migration exercises around allow/blocklisting initiatives that were already present in the enterprise, allowing for copy pasting from existing lists for upload into EPM in the one operation (per desired application group). 

The second functionality is a proof of concept translation of an export list from Applocker with allow/blocklisting rules for .exe files. With this, we’re taking that automation a step further, leveraging batch upload to automatically transfer an organisation’s existing application definitions over to EPM with minimal overhead.

## PREREQUISITES ##

To begin, you will need to manually create a file called constants.py.

It should have the following defined:

USERNAME = {Your EPM login name for the tenant}
PASSWORD = {The password corresponding to your login}
EPMServerName = {The server name of your EPM instance - as an example, "au.epm.cyberark.com" corresponds to the AU datacentre}
ApplicationID = {The name by which you want the EPM service to recognise this application's requests - e.g. "NicholaiAPITest"}

You will also need the packages defined in requirements.txt

This was compiled on Python 3.7.8

### VIRTUAL ENVIRONMENT ###

To run the application in a virtual python environment to minimise potential package conflicts, run the following in the root folder: 

    Powershell (Windows)
``python -m venv .``

``.\Scripts\activate`` 

``python -m pip install -r .\requirements.txt`` 

    Bash
``python -m venv .``

``source bin/activate`` 

``pip install -r ./requirements.txt`` 



<!-- ## CSV TEMPLATE FIELDS ##

SetID - the internal set ID you’re adding the application group to.

ObjectType - Currently accepts "exe" or "script"

Description - The long form explanation of the application group to which the application belongs. As this is not a 1:1 relationship, it is best to define the same description for all group items otherwise it will take the description of the last defined entry for the application/script/etc group.

DisplayName - Internal backend name for application

Filename - The exact name of the file in question - including any extensions. E.g. "notepad++.exe"

HashSHA-256 - to be used in conjunction with HashSHA-1 as per standard EPM practice.

Location - The directory where you’re expecting to find this file.

SubfoldersIncluded - Are we recursing through subdirectories when applying this rule? - Will not work without a location definition. True/False

ChildProcessesIncluded - Will we include child processes of this application in any policies targeting this entry? True/False

Publisher - The name (or part of the name) of the publisher on any signing certificate.

ComparePublisherAs - a value denoting how we look for the publisher string within the certificate
                    0 = exact, 1 = prefix, 2 = contains, 3 = wildcards, 4 = regExp

Version - TBD, doesn’t work with the current policy type selection

LocalDiskOnly - Does this apply strictly to local disk or is this for network shares, removable devices, etc.

HashSHA-1 - paired with HashSHA-256 to define hashed files to specifically allow or block.

AppLockerAction - Storage variable for app locker policy actions. This field exists purely to assist with AppLocker migrations to make manually defining groups easier.

## UTILITIES ##

Currently very much WIP.

Working on hashFile script to compute the hashes of files at a given list of locations for simplified upload as both SHA1 and SHA256 are required. These are currently untested. -->

## MODELS ##

This is the expected payload for an application group chunked down into patterns for ease of extensibility and edit.

## EPM AUTHENTICATION SERVICE ##

Token management and authentication handling via class abstraction. All handled in EPM-Main

<!-- ## EPM BATCH UPLOAD CSV TEMPLATE ##

The bucket for batch definitions of applications and scripts.

At a minimum for a successful definition it will need to be populated with:

SetID
ObjectType
FileName OR SHA1 & SHA256 OR Location OR Publisher & ComparePublisherAs
GroupName   -->

## EPM Api Service ##

Generic API call handling.

## EPM Data Service ##

API to business document translation layer

## Get Sets and Print ##

Handy utility for retrieving Set IDs with display name for ease of pasting into the batchUpload csv.

<!-- ## Proc Applocker XML ##

Takes an xml export from Applocker and processes it into the same format as the batchUpload csv - stored in AppLockerOutput.csv . This can then be readily copied across and adjusted for sets/groupings as desired by the user prior to upload.  -->

## EPM Postman Collection ##

This contains some of the test API calls that were used in building out this project's functionality.

## EPM Main ##

Creates application groups as per the definitions in the batchUpload csv and uploads these to EPM.


