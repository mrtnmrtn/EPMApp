from EPMAuthenticationService import EPMAuthenticationService
from Models.authResultModel import AuthResultModel
# import pip_system_certs.wrapt_requests
import requests, os, logging

class EpmApiService : 
    epmAuthService : EPMAuthenticationService
    # proxies = {
    #     'http':'http://127.0.0.1:8888',
    #     'https':'https://127.0.0.1:8888'
    # }
    # os.environ['HTTPS_PROXY']='https://127.0.0.1:8888'
    # os.environ['HTTP_PROXY']='http://127.0.0.1:8888'
    # os.environ['https_proxy']='https://127.0.0.1:8888'
    # os.environ['http_proxy']='http://127.0.0.1:8888'

    def __init__(self):
        self.epmAuthService = EPMAuthenticationService()

    # get sets
    def getSets(self):        
        authResult: AuthResultModel = self.epmAuthService.getToken()
        url = "{}/EPM/API/Sets".format(authResult.ManagerUrl)
        headers = {'Authorization' : authResult.Token}
        # return requests.get(url,headers=headers, proxies=self.proxies, verify=False).json()        
        return requests.get(url,headers=headers).json()        
    
    # Gets all the Policies of the Set
    def getPolicies(self, setId):
        authResult : AuthResultModel = self.epmAuthService.getToken()
        url =	"{}/EPM/API/Sets/{}/Policies/Server/Search?limit=1000&offset=0&sortBy=updated& sortDir=asc".format(authResult.ManagerUrl,setId)
        headers = {'Authorization' : authResult.Token}
        return  requests.post(url,headers=headers).json()
        # return  requests.post(url,headers=headers, proxies=self.proxies, verify=False).json()

    def getAppGroupDetails(self, setId, applicationGroupId):
        authResult : AuthResultModel = self.epmAuthService.getToken()
        url =	"{}/EPM/API/Sets/{}/Policies/ApplicationGroups/{}".format(authResult.ManagerUrl,setId, applicationGroupId)
        headers = {'Authorization' : authResult.Token}
        req = requests.get(url,headers=headers)
        # req = requests.get(url,headers=headers, proxies=self.proxies, verify=False)
        return req.json()

    def createApplicationGroup(self, setId, body):
        authResult : AuthResultModel = self.epmAuthService.getToken()
        headers = {'Authorization' : authResult.Token, 'Content-Type': 'application/json; charset=utf-8'}
        url = "{}/EPM/API/Sets/{}/Policies/ApplicationGroups".format(authResult.ManagerUrl, setId)

        response = requests.post(url, headers=headers, data=body)
        # response = requests.post(url, headers=headers, data=body, proxies=self.proxies, verify=False)
        
        if response.status_code not in [200, 201]:
            print("response.text: [{}] reason [{}] code [{}]".format(response.text, response.reason, response.status_code))
            try:
                print("request body: {}".format(body))            
            except:
                print("request body: {}".format(body.encode(encoding = 'UTF-8', errors = 'namereplace')))            

            print("response.json: {}".format(response.json()))
            print("url: {}".format(url))
        # else:
        #     print("[SUCCEEDED] response.status_code: {}".format(response.status_code))          

        return response.json()
    
    def deleteApplicationGroup(self, setId, applicationGroupId):
        authResult : AuthResultModel = self.epmAuthService.getToken()
        headers = {'Authorization' : authResult.Token, 'Content-Type': 'application/json; charset=utf-8'}
        url = "{}/EPM/API/Sets/{}/Policies/ApplicationGroups/{}".format(authResult.ManagerUrl, setId, applicationGroupId)
        response = requests.delete(url, headers=headers)

        if response.status_code not in [200, 201, 204]:
            logging.error("Unexpected response code [{}] when delete application group [{}] from set [{}]".format(response.status_code, applicationGroupId, setId))

        return response
        

    def updatePolicy(self, setId, policyId, body):
        authResult : AuthResultModel = self.epmAuthService.getToken()
        headers = {'Authorization' : authResult.Token, 'Content-Type': 'application/json; charset=utf-8'}
        url = "{}/EPM/API/Sets/{}/Policies/Server/{}".format(authResult.ManagerUrl, setId, policyId)

        response = requests.put(url, headers=headers, data=body)
        return response.json()
  
