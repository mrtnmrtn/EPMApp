
import hashlib
import csv
import copy
def parseCSV(filename):
            applications = []
            with open(filename, newline='') as csvfile:
                reader = csv.reader(csvfile, quotechar='|')
                for row in reader:
                    temp = copy.deepcopy(row)
                    applications.append(temp)
            return applications[1:]

def hashFile():
    filename = 'Location.csv'
    retArray=[]
    hashList = parseCSV(filename)
    BLOCK_SIZE = 655360 # The size of each read from the file
    for location in hashList:
        file_hashSHA256 = hashlib.sha256() # Create the hash object, can use something other than `.sha256()` if you wish
        with open(location, 'rb') as f: # Open the file to read it's bytes
            fb = f.read(BLOCK_SIZE) # Read from the file. Take in the amount declared above
            while len(fb) > 0: # While there is still data being read from the file
                file_hashSHA256.update(fb) # Update the hash
                fb = f.read(BLOCK_SIZE) # Read the next block from the file
        file_hashSHA1 = hashlib.sha1()
        with open(location, 'rb') as f: # Open the file to read it's bytes
            fb = f.read(BLOCK_SIZE) # Read from the file. Take in the amount declared above
            while len(fb) > 0: # While there is still data being read from the file
                file_hashSHA1.update(fb) # Update the hash
                fb = f.read(BLOCK_SIZE) # Read the next block from the file
        retArray.append([file_hashSHA1, file_hashSHA256, location])
    print(retArray)
    return retArray
