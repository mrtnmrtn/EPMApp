# from datetime import datetime, timedelta
import time, constants, logging

# from EPMAuthenticationService import EPMAuthenticationService
from EpmApiService import EpmApiService

from Models.authResultModel import AuthResultModel
from Models.ReferencedApplicationGroupModel import ReferencedApplicationGroupModel
from Models.ApplicationGroupDetailsPolicyModel import ApplicationGroupDetailsPolicyModel
from Models.ApplicationModel import ApplicationModel
from Models.PatternModel import PatternModel
from Models.LinkedAgentPolicy import LinkedAgentPolicy
from Models.PolicyModel import PolicyModel
from Models.SetModel import SetModel

from Documents.SetsResponse import SetsResponse
from Documents.PoliciesResponse import PoliciesResponse
from Documents.ApplicationGroupDetailsResponse import ApplicationGroupDetailsResponse

class EpmDataService :
    epmApiService : EpmApiService
    maxApiCallsPerPeriod=constants.MaxApiCallsPerPeriod
    periodSec=constants.ApiCallsPeriodSec
    apiCalledAt=[]

    def __init__(self):
        self.epmApiService = EpmApiService()
        self.apiCalledAt.append(time.time())

    def whenToCallApi(self):
        now = time.time()
        oldest = time.time() + 1000.0        
        deltaTime = self.periodSec
        if len(self.apiCalledAt) >= self.maxApiCallsPerPeriod:
            for i in self.apiCalledAt:
                if i < (now - deltaTime):
                    items=[i]
                    self.apiCalledAt = [e for e in self.apiCalledAt if e not in (items)]
                else:
                    if i < oldest:
                        oldest = i
            if len(self.apiCalledAt) < self.maxApiCallsPerPeriod:
                self.apiCalledAt.append(now)
            else:
                waitTime=oldest-(now-deltaTime)                
                self.apiCalledAt.append(now + waitTime)
                if waitTime > 0:
                    return waitTime + 1
                else:
                    return 0
        else:
            self.apiCalledAt.append(now)
            return 0
        return 0

    # get list of sets and return list of setId's and names
    def getSets(self):
        time.sleep(self.whenToCallApi())

        response = SetsResponse()
        logging.info("about to get sets")
        responseJson = self.epmApiService.getSets()

        # populate set response object
        for set in responseJson["Sets"]:
            setModel = SetModel()
            setModel.Id = set["Id"]
            setModel.Name = set["Name"]
            setModel.Description = set["Description"]
            setModel.IsNPVDI = set["IsNPVDI"]
            setModel.SetType = set["SetType"]
            response.addSet(setModel)

        return response

    # Gets all the Policies of the Set
    def getPolicies(self, setId):
        time.sleep(self.whenToCallApi())

        response = PoliciesResponse()
        logging.info("about to get policies in set [{}]".format(setId))
        responseJson = self.epmApiService.getPolicies(setId)

        for policy in responseJson["Policies"]:
            rags = []
            for rag in policy["ReferencedApplicationGroups"]:
                rags.append(ReferencedApplicationGroupModel(rag["Id"], rag["ReferenceType"]))

            policyModel = PolicyModel()

            if ("PolicyId" in policy):
                policyModel.PolicyId=policy["PolicyId"]
            if ("PolicyName" in policy):
                policyModel.PolicyName=policy["PolicyName"]
            if ("Action" in policy):
                policyModel.Action=policy["Action"]
            if ("IsActive" in policy):
                policyModel.IsActive=policy["IsActive"]
            if ("PolicyType" in policy):
                policyModel.PolicyType=policy["PolicyType"]
            if ("Order" in policy):
                policyModel.Order=policy["Order"]
            if ("IsAppliedToAllComputers" in policy):
                policyModel.IsAppliedToAllComputers=policy["IsAppliedToAllComputers"]
            if ("OsType" in policy):
                policyModel.OsType=policy["OsType"]
            if ("CreatedDate" in policy):
                policyModel.CreatedDate=policy["CreatedDate"]
            if ("ModifiedDate" in policy):
                policyModel.ModifiedDate=policy["ModifiedDate"]
            if ("UserPolicyPermissions" in policy):
                policyModel.UserPolicyPermissions=policy["UserPolicyPermissions"]
            if ("ExtraInfo" in policy):
                policyModel.ExtraInfo=policy["ExtraInfo"]
            policyModel.ReferencedApplicationGroups=rags

            response.addPolicyModel(policyModel)
            response.activeCount = responseJson["ActiveCount"]
            response.totalCount = responseJson["TotalCount"]
            response.filteredCount = responseJson["FilteredCount"]

        return response

    def getAppGroupDetails(self, setId, applicationGroupId):
        time.sleep(self.whenToCallApi())
        response : vars
        try:
            logging.info("about to get details for app group [{}] in set [{}]".format(applicationGroupId, setId))
            responseJson = self.epmApiService.getAppGroupDetails(setId, applicationGroupId)

            linkedAgentPolicies = []
            for pol in responseJson["Policy"]["LinkedAgentPolicies"]:
                linkedAgentPolicies.append(LinkedAgentPolicy(pol["Id"], pol["PolicyType"], pol["DefaultApplicationGroupId"]))

            applications = []
            for apps in responseJson["Policy"]["Applications"]:
                application=ApplicationModel()

                childProcess : vars
                id : vars
                internalId : vars
                applicationType : vars
                displayName : vars
                description : str
                patterns : vars
                applicationGroupId : vars
                internalApplicationGroupId : vars
                includeInMatching : vars
                accountId : vars
                restrictOpenSaveFileDialog : vars
                securityTokenId : vars
                protectInstalledFiles : vars

                if ("childProcess" in apps):
                    childProcess=apps["childProcess"]
                # if ("id" in apps):
                #     id=apps["id"]
                # if ("internalId" in apps):
                #     internalId=apps["internalId"]
                if ("applicationType" in apps):
                    applicationType=apps["applicationType"]
                if ("displayName" in apps):
                    displayName=apps["displayName"]
                if ("description" in apps):
                    description=apps["description"]
                if ("patterns" in apps):
                    patterns=apps["patterns"]                  
                if ("applicationGroupId" in apps):
                    applicationGroupId=apps["applicationGroupId"]
                if ("internalApplicationGroupId" in apps):
                    internalApplicationGroupId=apps["internalApplicationGroupId"]
                if ("includeInMatching" in apps):
                    includeInMatching=apps["includeInMatching"]
                if ("accountId" in apps):
                    accountId=apps["accountId"]
                if ("restrictOpenSaveFileDialog" in apps):
                    restrictOpenSaveFileDialog=apps["restrictOpenSaveFileDialog"]
                if ("securityTokenId" in apps):
                    securityTokenId=apps["securityTokenId"]
                if ("protectInstalledFiles" in apps):
                    protectInstalledFiles=apps["protectInstalledFiles"]

                # application.id=id
                # application.internalId=internalId
                application.applicationType=applicationType
                application.displayName=displayName
                application.description=description
                application.applicationGroupId=applicationGroupId
                application.internalApplicationGroupId=internalApplicationGroupId
                application.includeInMatching=includeInMatching
                application.accountId=accountId
                application.childProcess=childProcess
                application.restrictOpenSaveFileDialog=restrictOpenSaveFileDialog
                application.securityTokenId=securityTokenId
                application.protectInstalledFiles=protectInstalledFiles
                application.patterns=patterns

                applications.append(application)

            # print("###################################################", flush=True)
            #create ApplicationGroupDetailsPolicyModel
            applicationGroupDetailsPolicyModel = ApplicationGroupDetailsPolicyModel()
            applicationGroupDetailsPolicyModel.id=responseJson["Policy"]["Id"]
            applicationGroupDetailsPolicyModel.Name=responseJson["Policy"]["Name"]

            policyType = responseJson["Policy"]["PolicyType"]
            applicationGroupDetailsPolicyModel.PolicyType=policyType

            applicationGroupDetailsPolicyModel.description=responseJson["Policy"]["Description"]
            applicationGroupDetailsPolicyModel.Applications=applications
            applicationGroupDetailsPolicyModel.linkedAgentPolicies=linkedAgentPolicies

            response = ApplicationGroupDetailsResponse(
                applicationGroupDetailsPolicyModel=applicationGroupDetailsPolicyModel
                , createdDate=responseJson["CreatedDate"]
                , modifiedDate=responseJson["ModifiedDate"]
                , order=responseJson["Order"]
                , osType=responseJson["OsType"]
                )
        except Exception as exception:
            print("*******EXCEPTION (GENERAL) -- {}".format(exception))
            print("*******EXCEPTION (GENERAL) -- {}".format(responseJson))
            raise exception
        # exit()
        return response

    def createApplicationGroup(self, setId, body):
        time.sleep(self.whenToCallApi())
        response : ApplicationGroupDetailsPolicyModel
        try:
            logging.info("about to create app group [{}] in set [{}]".format(body.Name, setId))
            responseJson = self.epmApiService.createApplicationGroup(setId, body.toJson())
            
            response = ApplicationGroupDetailsPolicyModel()
            response.Applications=responseJson["Applications"]
            response.description=responseJson["Description"]
            response.Name=responseJson["Name"]
            response.id=responseJson["Id"]
            response.linkedAgentPolicies=responseJson["LinkedAgentPolicies"]
            response.PolicyType=responseJson["PolicyType"]
            
        except Exception as exception:
            print("*******EXCEPTION (GENERAL) -- {}".format(exception))
            raise exception

        return response

    def updatePolicy(self, setId, policyId, body):
        time.sleep(self.whenToCallApi())
        response : vars
        try:
            logging.info("about to update policy [{}] in set [{}]".format(policyId, setId))
            responseJson = self.epmApiService.updatePolicy(setId, policyId, body.toJson())
            response = responseJson
        except Exception as exception:
            print("*******EXCEPTION (GENERAL) -- {}".format(exception))
            raise exception
        return response

    def deleteApplicationGroup(self, setId, applicationGroupId):
        time.sleep(self.whenToCallApi())
        response : vars
        try:        
            logging.info("about to delete app group [{}] in set [{}]".format(applicationGroupId, setId))
            response = self.epmApiService.deleteApplicationGroup(setId, applicationGroupId)
        except Exception as exception:
            print("*******EXCEPTION (GENERAL) -- {}".format(exception))
            logging.error("exception when trying to delete application group [{}] from set [{}]".format(applicationGroupId, setId))
            raise exception
        return response





    # # gets the application groups inside provided SetId
    # def getApplicationGroups(self, setId):
    #     authResult : AuthResultModel = self.epmAuthService.getToken()
    #     url = "{}/EPM/API/Sets/{}/Policies/ApplicationGroups/Search?limit=500&offset=0&sortBy=Updated& sortDir=asc".format(authResult.ManagerUrl,setId)
    #     headers = {'Authorization' : authResult.Token}
    #     return requests.post(url, headers=headers).json()

